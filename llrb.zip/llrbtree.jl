# Here we define the LLRBTree data structure, that allows us to acces keys in log2 time
module LLRBTrees

# Are we debugging?
global isDebug = false

# We import the basic julia interfaces that allow us to acces the values to our keys
#  like so tree[key]=value
import Base: haskey, getindex, setindex!, delete!, minimum, push!

# The public types and methods to be exported
export TreePart, TreeLeaf, TreeNode, LLRBTree, getnodefrom_key, setdebug, getmaxdepth

#Set debugging
function setdebug(isDebug_::Bool)
    global isDebug = isDebug_
end

# We declare an abstract type, that contains the nodes and the leaves of the tree
abstract TreePart

# The TreeNode type with parametric freedom of type for its key and values
type TreeNode{K,V} <: TreePart
    key::  K
    value:: V
    isRed::Bool
    left:: TreePart
    right:: TreePart
end
# We need to use external constructors to be able to omit the parameters
# Nodes are always red so no method that explicitly assings the color is neccessary
TreeNode{K,V}(key::K,value::V,left::TreePart,right::TreePart) = TreeNode(key,value,true,left,right)
TreeNode{K,V}(key::K,value::V) = TreeNode(key, value, true, TreeLeaf(), TreeLeaf())

# Empty nodes (leaves) only have a color field
type TreeLeaf <: TreePart
    isRed::Bool
    # Leaves are always black
    TreeLeaf()=new(false)
end

# To be able to have different instances of LLRB trees, we create a tree type
# that characterizes a tree by its root
type LLRBTree
    root:: TreePart

    LLRBTree(node::TreePart) = (tree = new(); tree.root=node; tree.root.isRed=false; tree)
end
# We want to be able to create a tree wthout specifying the values of its root
LLRBTree() = LLRBTree(TreeLeaf())
LLRBTree(key, value) = (tree=LLRBTree(TreeNode(key,value)))

# The function that returns the node that corresponds to a certain key, below a root-node
# it returns a TreeLeaf when the root node is empty
function getnodefrom_key(part::TreePart, key)
    # Return leaf if node is leaf
    if isa(part,TreeLeaf)
        return part

    # Check if root key is of the same type as given key
    elseif !isa(part.key,typeof(key))
        throw(ArgumenError("The type of the searched key must have the same type as the key of the root node"))

    # The recursive search for the key
    elseif part.key == key
        return part
    elseif key < part.key
        getnodefrom_key(part.left, key)
    else
        getnodefrom_key(part.right, key)
    end
end
# Generally one gives the tree as an argument, this method handles that case
# If the tree is empty it returns a TreeLeaf
getnodefrom_key(tree::LLRBTree, key) = getnodefrom_key(tree.root, key)

# A method that extends the haskey function from julia
haskey(tree::LLRBTree, key) = isa(getnodefrom_key(tree, key), TreeLeaf) ? false : true
haskey(node::TreeNode, key) = isa(getnodefrom_key(node, key), TreeLeaf) ? false : true

# A getindex method for our tree structure
# only that the indexes are keys and we get the value of the first node with the given key
function getindex(tree::LLRBTree, key)
    part::TreePart = getnodefrom_key(tree,key)
    # Throw a KeyException if the key is node.left present
    if isa(part, TreeLeaf)
        throw(KeyException(key))
    else
        return part.value
    end
end

# A setindex function that will let us assign values in this way tree[key]=value
function setindex!(tree::LLRBTree, value, key)
    part::TreePart = getnodefrom_key(tree,key)
    # Throw a KeyException if the key is not present
    if isa(part, TreeLeaf)
        throw(KeyException(key))
    else
        part.value=value
    end
end

# Rotate the node to the left
#         |                                                             |
#       node                              -> rotateleft ->             son
#       /   \                                                         /  \
#           son                                                      node
#          /   \                                                    /  \
function rotateleft(node::TreeNode)
    son=node.right

    if isa(son, TreeLeaf)
        error("The right part of the given node must be a node")
    end

    node.right=son.left
    son.left=node
    son.isRed=node.isRed
    node.isRed=true
    return son
end

# Rotate the node to the right
#         |                                                              |
#        node                              -> rotateright ->            son
#       /   \                                                          /  \
#     son                                                               node
#    /   \                                                              /  \
function rotateright(node::TreeNode)
    son=node.left

    if isa(son, TreeLeaf)
        error("The left part of the given node must be a node")
    end

    node.left=son.right
    son.right=node
    son.isRed=node.isRed
    node.isRed=true
    return son
end

# Flips the color of the node
function flipcolor!(node::TreeNode)

    node.isRed = !node.isRed
    node.left.isRed = !node.left.isRed
    node.right.isRed = !node.right.isRed
end

# Adds the specified key/value pair below the specified root node.
# Shouldn't be exported because the tree root would not be updated
function add_node{K,V}(node::TreePart, key::K, value::V)

    if isa(node, TreeLeaf)
        # Add the node only when a leaf is found
         #("node added")
        return TreeNode(key, value)
    end

    if node.left.isRed && node.right.isRed
         #("Split node with two red children")
        flipcolor!(node)
         #(node)
    end

    if node.key <= key
         #("went right")
        node.right = add_node(node.right, key, value)
    else
         #("went left")
        node.left = add_node(node.left, key, value)
    end

    if node.right.isRed
         #("Rotate left to prevent red node on right")
        node=rotateleft(node)
         #(node)
    end
    if node.left.isRed && node.left.left.isRed
         #("Rotate right to prevent consecutive red nodes")
        node=rotateright(node)
         #(node)
    end
     #("We return the node for the recursion")
    return node
end
# For trees and nodes as parameters, different name so the other one doesn't get used
push!{K,V}(tree::LLRBTree, key::K, value::V) = (tree.root = add_node(tree.root, key, value); tree.root.isRed=false; tree)
push!{K,V}(tree::LLRBTree, node::TreeNode{K,V}) = (tree.root = add_node(tree.root, node.key, node.value); tree.root.isRed=false; tree)

# Move the red node left
function moveredleft{K,V}(node::TreeNode{K,V})
    flipcolor!(node)
    if (node.right.left.isRed==true)
        node.right = rotateright(node.right)
        node = rotateleft(node)
        flipcolor!(node)

        #Avoid creating right-leaning nodes
        if (node.right.right.isRed)
            node.right = rotateleft(node.right)
        end
    end
    return node
end

# Move the red node right
function moveredright{K,V}(node::TreeNode{K,V})
    flipcolor!(node)
    if (node.left.left.isRed==true)
        node= rotateright(node)
        flipcolor!(node)
    end
    return node
end

# Gets the minimum below a certain node
function minimum{K,V}(node::TreeNode{K,V})
    while !isa(node.left,TreeLeaf)
        node=node.left
    end
    return node
end
minimum(tree::LLRBTree) = minimum(tree.root)

# Maintains invariants by adjusting the specified nodes children.
# returns new root node
function fixup{K,V}(node::TreeNode{K,V})
    if (node.right.isRed)
        node=rotateleft(node)
    end
    if (isa(node.left,TreeLeaf) && node.left.isRed && h.left.left.isRed)
        node=rotateright(node)
    end
    if (node.left.isRed && node.right.isRed)
        flipcolor!(node)
    end
    return node
end

# Deletes the minimum node under the specified node.
function deletemin{K,V}(node::TreeNode{K,V})
    if isa(node.left, TreeLeaf)
        # Nothing to do
        return TreeLeaf()
    end
    if !node.left.isRed && !node.left.left.isRed
        # Move red node left
        node=moveredleft(node)
    end
    # Recursively delete
    node.left=deletemin(node.left)
    fixup(node)
end


# Removes the specified key from below the specified node.
function delete_node{K,V}(node::TreeNode{K,V}, key::K)
    #("Entering node")
    if key<node.key
        if !isa(node.left, TreeLeaf)
            #("* Continue search if left is present")
            if (!node.left.isRed && !node.left.left.isRed)
                #("Move a red node over")
                node=moveredright(node)
            end
            #("Remove from left recursion")
            node.left=delete_node(node.left, key)
        else
            #("Left node was leaf so key cannot be here")
            throw(KeyError(key))
        end
    else
        if (node.left.isRed)
            #("Flip a 3 node or unbalance a 4 node")
            node=rotateright(node)
        end
        if key==node.key && isa(node.right,TreeLeaf)
            #("Delete the node to the left")
            return TreeLeaf()
        end
        if !isa(node.right, TreeLeaf)
            #("* Continue search if right is present")
            if (!node.right.isRed && !node.right.left.isRed)
                #("Move a red node over")
                node=moveredright(node)
            end
            if key==node.key
                #("Find the smallest node on the right, swap, and remove it")
                min = minimum(node.right)
                node.key=min.key
                node.value=min.value
                node.right=deletemin(node.right)
            else
                  #("Remove from right recursion")
                node.right=delete_node(node.right,key)
            end
        else
            #("Right node was leaf so key cannot be here")
            throw(KeyError(key))
        end
    end
      #("Maintain invariants and go one level up")
    return fixup(node)
end
# Removes the specified key from the tree
delete!{K}(tree::LLRBTree, key::K) = (tree.root = delete_node(tree.root,key); tree)

#Get the maximum depth of the tree
function getmaxdepth{K,V}(node::TreeNode{K,V}, depth=1)
    #We do a caching up of the number of recursions with the use of parameters and returns
    depthleft=depthright=depth
    if !isa(node.left, TreeLeaf)
        #("left in at $depth")
        depthleft = getmaxdepth(node.left, depth+1)
    end
    if !isa(node.right, TreeLeaf)
        #("right in at $depth")
        depthright = getmaxdepth(node.right, depth+1)
    end
    #("out at $depth")
    #([depthleft,depthright])
    return maximum([depthleft,depthright])
end
getmaxdepth(tree::LLRBTree) = getmaxdepth(tree.root)

#Return an ordered list with recursion
function inorder(node::TreePart, list={})
    if !isa(node, TreeLeaf)

        if !isa(node.left, TreeLeaf)
            #("Go down to the left first")
            list = inorder(node.left, list)[2]
        end

        #("Push to the list when leftmost")
        push!(list, [node.key, node.value])

        if !isa(node.right, TreeLeaf)
            #("Go right if no left")
            list = inorder(node.right, list)[2]
        end
    end
    #("Go up;  ",node,";  ",list)
    return node, list
end
orderedpairs(tree::LLRBTree) = inorder(tree.root)[2]

#A module for visualizing LLRBtrees
module LLRBVisualize

using LLRBTrees
using Compose

export iterate_undernode, drawASCII, draw

#Columns in which the nodes are to be drawn
abstract Column

#For the left and rightmost columns
type ColumnEmpty <: Column
end

#The idea is that one can insert a column between two columns making space for any new node
#That is why we need a link to both sides
type ColumnFull <: Column
    left:: Column
    right:: Column
    parent::Column
    node:: TreePart
    height :: Int64

    ColumnFull(node :: TreePart) = new(ColumnEmpty(), ColumnEmpty(), ColumnEmpty(), node, 1)
    ColumnFull(cleft:: Column, cright::Column, cparent::Column, node::TreePart, height :: Int64) = new(cleft, cright, cparent, node, height)
end
#Get the place from left to right of the given column
function columnindex(col::ColumnFull)
    i=0
    while !isa(col, ColumnEmpty)
        i+=1
        col=col.left
    end
    i
end

#Builds the columns in which the nodes connected to the node in the parameter should be drawn
function buildcolumns(col::ColumnFull)

    leftnode = col.node.left
    rightnode = col.node.right

    #First create the columns recursively to the left until there are no more nodes
    if isa(leftnode, TreeNode)
        #Creation of the new column
        colleft = ColumnFull(col.left, col, col, leftnode, col.height+1)

        #Correcting links
        col.left = ColumnEmpty()
        if isa(colleft.left, ColumnFull)
            colleft.left.right = colleft
        end
        col.left = colleft

        #Recursion
        buildcolumns(colleft)
    end

    if isa(rightnode, TreeNode)
        #Creation of the new column
        colright = ColumnFull(col, col.right, col, rightnode, col.height+1)

        #Correcting links
        col.right = ColumnEmpty()
        if isa(colright.right, ColumnFull)
            colright.right.left = colright
        end
        col.right = colright

        #Recursion
        buildcolumns(colright)
    end
    return col
end

buildcolumns(tree::LLRBTree) = buildcolumns( ColumnFull(tree.root) )

function spacestring(length::Int64, space="    " )
   string=""
    for i in 1:length
        string = "$string$space"
    end
    string
end

#The column given must be the one that contains the root node
function drawASCII(col::ColumnFull)

    #Store max height for calculating indent
    maxheight=getmaxdepth(col.node)

    #Get the leftmost column
    while !isa(col.left, ColumnEmpty)
       col = col.left
    end

    #Print from left to right
    while true
        length = maxheight - col.height
        println(spacestring(length), col.node.key)
        col = col.right
        isa(col, ColumnEmpty) && break
    end
end
drawASCII(tree::LLRBTree) =( col = buildcolumns(tree); drawASCII(col) )

#Returns an array that has the coordinates in which the nodes are to be drawn,
#the index of the parents for drawing the connections and the value to be printed inside
#The column given must be the one that contains the root node
function getcoords(col::ColumnFull)

    #Get the y dimension
    maxheight=getmaxdepth(col.node)

    #We'll start writing from the left
    while !isa(col.left, ColumnEmpty)
       col = col.left
    end

    #Get the x dimension
    length=1
    col2=col
    while !isa(col2.right, ColumnEmpty)
       col2 = col2.right
        length+=1
    end

    #Define the cell dimensions in relative coordinates
    width=1/length
    height=1/maxheight
    coords = {}

    #Write to the array from left to right
    x = -width
    while true
        y = -height/2 + col.height*height
        x += width
        parentid = isa(col.parent, ColumnFull) ? columnindex(col.parent): 0
        push!( coords, { x, y, parentid, col.node.value } )

        col = col.right
        isa(col, ColumnEmpty) && break
    end

    coords
end

#Draw the circles with the help of Compose.jl
function draw(coords, color = "blue")
    circles = {}
    lines = {}
    width = length(coords)
    #Make a list of all the circles to be drawn
    for i in 1:width

        x = coords[i][1]
        y = coords[i][2]

        #Build the line from children to parent if present
        parent = coords[i][3]
        if parent!=0
            xp= coords[parent][1]
            yp= coords[parent][2]

            ad = 0.5/width

            treeline = compose(context(), line([(x+ad, y+ad), (xp+ad, yp+ad)]) )
            push!(lines, treeline)
        end

        #Build the circle

        circle_ = treecircle(x, y, 1/width, string(coords[i][4]) )
        push!(circles, circle_)
    end

    #Draw them
    compose(context(), circles..., lines..., stroke("black"), fill(color), fontsize(1/width*50), linewidth(0.1mm))
end
draw(col::ColumnFull, color = "blue") = draw(getcoords(col),color)
draw(tree::LLRBTree, color = "blue") = draw(buildcolumns(tree),color)

function treecircle(x::Float64, y::Float64, side::Float64, value::String)
    compose(context(x, y, side, side), circle(), (context(0,0), text(0.2,0.55,value), fill("black")))
end

function iterate_undernode(node::TreePart, isLeft::Bool=true)
    if isa(node,TreeLeaf)
        compose(context(), polygon([(1,1), (0,1), (1/2, 0)]))
        #=if isLeft
                                compose(context(), polygon([(1,0.5), (0,0)]))
                            else
                                compose(context(), polygon([(1,0.5), (0,1)]))
                            end=#
    else
        left=iterate_undernode(node.left, true)
        right=iterate_undernode(node.right, false)
        compose(context(),
                #polygon([(1,1), (0,1), (1/2, 0)]),
                #rectangle(),
                (context(1/2,   0, 1/2, 1/2), left),
                (context(  0, 0, 1/2, 1/2), right))
    end
end
#LLRBVisualize end
end


end

